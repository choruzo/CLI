window.__STRATUM_COMMITS__ = {
  "generatedAt": "2026-06-19T17:51:47.2178241+02:00",
  "repository": "choruzo/CLI",
  "branch": "main",
  "commits": [
    {
      "sha": "68922a94edfc54cc6187df46e8823be9cd0f75b0",
      "date": "2026-06-19T16:32:07+02:00",
      "author": "Javi_1",
      "subject": "feat(plan): implement present_plan tool for user approval in planning phase"
    },
    {
      "sha": "6e20ef4375f47f2a562bacebd1e24a21b64157f8",
      "date": "2026-06-19T16:22:28+02:00",
      "author": "Javi_1",
      "subject": "feat: implement plan and execute feature in chat and run commands Hito 7"
    },
    {
      "sha": "7e1f139a032eceb4ac3547fc9e8ed17c6ccc8d45",
      "date": "2026-06-19T14:38:35+02:00",
      "author": "Javi_1",
      "subject": "feat(docs): enhance project definition with plan persistence and resumption details"
    },
    {
      "sha": "890666182c26f8756f72c2a93cf47d7299f6e813",
      "date": "2026-06-19T14:25:00+02:00",
      "author": "Javi_1",
      "subject": "feat(ui): implement Plan & Execute mode with approval workflow and UI updates"
    },
    {
      "sha": "359bd5bc841f149329882e6b8ca54fe628d46664",
      "date": "2026-06-19T13:57:33+02:00",
      "author": "Javi_1",
      "subject": "fix(docs): update deliverable description for plan command in project definition"
    },
    {
      "sha": "9bd35a2ec4babb9290dc679fe8990c67afcbcb76",
      "date": "2026-06-19T10:21:37+02:00",
      "author": "Javi_1",
      "subject": "fix(ci): make pack step robust in actions"
    },
    {
      "sha": "e96267bc8809cb6de4dd406ee33719e11b484fd4",
      "date": "2026-06-19T10:18:58+02:00",
      "author": "Javi_1",
      "subject": "fix(ci): avoid npm pack JSON parse failure"
    },
    {
      "sha": "72faaf9029f1589e84b0ffee747f97baa90d4708",
      "date": "2026-06-19T10:15:51+02:00",
      "author": "Javi_1",
      "subject": "chore: release v0.2.0"
    },
    {
      "sha": "4712d3af3c7d3d4a95fbc9394fb0856875b1222b",
      "date": "2026-06-19T10:08:47+02:00",
      "author": "Upgrade some files up to date",
      "subject": "chore: guardar cambios pendientes antes de release"
    },
    {
      "sha": "8b2831c54b4549245f48f1afd55be2fc39d6a702",
      "date": "2026-06-19T09:57:01+02:00",
      "author": "Javi_1",
      "subject": "feat: implement multi-provider support and health check functionality"
    },
    {
      "sha": "1cadd033028fc84125db4a770cbdf1190c46dabe",
      "date": "2026-06-18T17:38:32+02:00",
      "author": "Javi_1",
      "subject": "feat(tests): enhance test cases with improved cleanup and deterministic behavior"
    },
    {
      "sha": "67e75789e4234e7974ca2c3c6ea7f1370b329a1e",
      "date": "2026-06-17T21:36:45+02:00",
      "author": "Javi_1",
      "subject": "feat(logging): implement structured logging with configurable levels and sinks"
    },
    {
      "sha": "515e7c1a9b999a8fe262bd5ca2db586c16145991",
      "date": "2026-06-17T20:58:09+02:00",
      "author": "Javi_1",
      "subject": "feat: implement MCP diagnostic logging and integrate with McpManager"
    },
    {
      "sha": "78b7ca4be4ff2a9aee1d9c9bed39b86b17f7f5de",
      "date": "2026-06-17T20:55:00+02:00",
      "author": "Javi_1",
      "subject": "feat: capture stderr from MCP server to improve UI cleanliness and diagnostics"
    },
    {
      "sha": "9771436b6a088bd18eb925f4d22bc06c0d59e9f4",
      "date": "2026-06-17T20:34:58+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance decision memory with indexing and error handling"
    },
    {
      "sha": "45d5ed75cd611d73b1484d1bc4f37af5763fa6d6",
      "date": "2026-06-17T17:12:27+02:00",
      "author": "jmartinb",
      "subject": "feat: enhance McpServerSchema validation and ensure command presence when package is absent"
    },
    {
      "sha": "54c3b0d068f9dae3d0188791dc3ebf5f9d826a94",
      "date": "2026-06-17T10:03:02+02:00",
      "author": "Javi_1",
      "subject": "feat: update embedding configuration with new parameters for enhanced performance"
    },
    {
      "sha": "259c3a731931c15357dcd774e6eda0847fb14f1d",
      "date": "2026-06-16T20:45:11+02:00",
      "author": "Javi_1",
      "subject": "Actualiza la documentación de los módulos `memory`, `providers` y `tools` para reflejar los cambios en los hitos y la implementación. Se completa el Hito 5 con la integración de `DecisionStore`, `EmbeddingService` y `VectorStore`. Se añaden nuevas herramientas y funcionalidades en el módulo `tools`, incluyendo mejoras en la gestión de MCP. Se ajustan las fechas y se detallan las nuevas características y comandos en el roadmap."
    },
    {
      "sha": "1ed9b63d6663ba313dece68d71f08edb0d0427d3",
      "date": "2026-06-16T18:28:46+02:00",
      "author": "Javi_1",
      "subject": "feat: add UI enhancements for memory commands and visual indicators"
    },
    {
      "sha": "d41ee772df54fc56dfa8ab2bf6cc11a9c34fce0a",
      "date": "2026-06-16T18:12:27+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance memory management with new commands and retrieval features"
    },
    {
      "sha": "64e85d2197eec70e2b3a32b4141f698752912622",
      "date": "2026-06-16T18:09:25+02:00",
      "author": "Javi_1",
      "subject": "Remove obsolete test files and configuration for MCP tools and CLI build"
    },
    {
      "sha": "389313223fd4d93542ea6049b75cdc4bbd5cf26c",
      "date": "2026-06-16T17:50:55+02:00",
      "author": "Javi_1",
      "subject": "feat: add recall_decisions tool for retrieving past technical decisions"
    },
    {
      "sha": "33ade0748c5ce92e58e0eb78005684ed49e2c179",
      "date": "2026-06-16T17:50:42+02:00",
      "author": "Javi_1",
      "subject": "feat(mcp): implement McpManager and related tools with comprehensive tests"
    },
    {
      "sha": "6be3e749ef2dc03621e27593927dee3a57a88bf5",
      "date": "2026-06-16T17:08:34+02:00",
      "author": "Javi_1",
      "subject": "feat: update milestone for MCP Client integration and tool registration"
    },
    {
      "sha": "e5b83bf7f5e82e27a223757bbf600761394c6660",
      "date": "2026-06-16T12:55:59+02:00",
      "author": "Javi_1",
      "subject": "feat: remove obsolete vitest configuration files"
    },
    {
      "sha": "d90d3f0299693df8dc572bb19c31ffc256d298df",
      "date": "2026-06-16T12:44:56+02:00",
      "author": "Javi_1",
      "subject": "feat(mcp): implement managed server folder and non-blocking startup for MCP servers"
    },
    {
      "sha": "5448a498837bac2d33d1ff4f8a6b9d96a903d425",
      "date": "2026-06-15T16:35:42+02:00",
      "author": "Javi_1",
      "subject": "feat(mcp): implement MCP server client and tool management"
    },
    {
      "sha": "6e9e3a98bba9e52af27409c2374ba318fa3b314b",
      "date": "2026-06-15T09:58:54+02:00",
      "author": "Javi_1",
      "subject": "feat: add implementation milestone plan for Stratum Desktop"
    },
    {
      "sha": "192f30d05f86e0f104445947570e45969a509bc2",
      "date": "2026-06-14T21:12:14+02:00",
      "author": "Javi_1",
      "subject": "feat: update project definition with sidecar architecture and IPC improvements"
    },
    {
      "sha": "67679fcc2d05507ea69770f1c9b7215edbcdc706",
      "date": "2026-06-14T21:00:21+02:00",
      "author": "Javi_1",
      "subject": "feat: add design review section with identified blind spots and recommendations"
    },
    {
      "sha": "0bf75868f41db8d95098e1477c41892262ac4564",
      "date": "2026-06-14T20:54:28+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance project definition with window management and onboarding flow details"
    },
    {
      "sha": "86d553a356aa3ecc73c901592614d4c9fd2cdc58",
      "date": "2026-06-14T20:44:56+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance sidebar specifications with detailed structure and behavior"
    },
    {
      "sha": "d7efc38c43336f7833837bdd4a5980be053ebbd5",
      "date": "2026-06-12T15:25:46+02:00",
      "author": "Javi_1",
      "subject": "feat: update STRATUM.md with window dimensions and sidebar enhancements"
    },
    {
      "sha": "2bf29028617e83de95fe3ddaa00d014aa7231d10",
      "date": "2026-06-12T14:43:35+02:00",
      "author": "Javi_1",
      "subject": "feat: add project definition and specifications for web search improvements"
    },
    {
      "sha": "a783ff4f106c858dc6d2613079410953ddcfd166",
      "date": "2026-06-12T10:22:12+02:00",
      "author": "Javi_1",
      "subject": "feat: add MaskedInput and SelectList components for improved user input handling"
    },
    {
      "sha": "975b40dff128bd32e7b13653d87881e7515ff639",
      "date": "2026-06-11T18:56:53+02:00",
      "author": "Javi_1",
      "subject": "feat: add web tools for fetching and searching content"
    },
    {
      "sha": "0740133cc60e36224fc4d22f6fd51b936965c09a",
      "date": "2026-06-11T14:30:39+02:00",
      "author": "Javi_1",
      "subject": "feat: update README and project definition for improved tool descriptions and memory layer milestones test: add tests for loading global and project STRATUM.md files in MemoryManager fix: refine context provider documentation in StratumAgent refactor: unify excluded directories in glob and list tools"
    },
    {
      "sha": "756675dacfad4d44642987faa09bab7e64b87f53",
      "date": "2026-06-11T14:17:23+02:00",
      "author": "Javi_1",
      "subject": "fix: enhance STRATUM.md writing logic and error handling in initialization process"
    },
    {
      "sha": "5b8a706a25680740c104894de189e59166fc8e56",
      "date": "2026-06-11T08:13:40+02:00",
      "author": "Javi_1",
      "subject": "feat: Enhance Stratum CLI with new tools and improvements"
    },
    {
      "sha": "d983ab07ba18bddf58d765ccf9ccc1a6caa58f8c",
      "date": "2026-06-09T21:39:54+02:00",
      "author": "Javi_1",
      "subject": "fix: validate assistant message before storing to prevent invalid entries"
    },
    {
      "sha": "0599293533e2f272951383964781a9f2e1987a16",
      "date": "2026-06-09T21:04:28+02:00",
      "author": "Javi_1",
      "subject": "fix: update default provider configuration to use 'litellm' with correct API settings"
    },
    {
      "sha": "1090dd4c5a8902a27d9bc4eacca8d14ba721f5de",
      "date": "2026-06-09T20:52:07+02:00",
      "author": "Javi_1",
      "subject": "feat: implement initialization process for agent with progress updates and completion handling"
    },
    {
      "sha": "3feea9ed7330ec2de10572f445b598863e544479",
      "date": "2026-06-09T20:33:37+02:00",
      "author": "Javi_1",
      "subject": "Refactor Stratum initialization process: remove InitReActExplorer, integrate new initialization prompt, and streamline command handling in CLI. Update tests accordingly."
    },
    {
      "sha": "b3beec2dc9315fa335245ae4447026434090a21a",
      "date": "2026-06-09T19:28:13+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance model selection and provider configuration commands; update config loading logic"
    },
    {
      "sha": "9845ff966e008c3ba315f324624aae1eb0eafc70",
      "date": "2026-06-05T11:56:45+02:00",
      "author": "Javi_1",
      "subject": "feat: add interactive provider management wizard and model selection commands"
    },
    {
      "sha": "7b702599ef76da91844346e8bc73854f3da6155f",
      "date": "2026-06-02T22:18:22+02:00",
      "author": "Javi_1",
      "subject": "feat: implement Hito 2.5 — Init Agent ReAct Explorer"
    },
    {
      "sha": "3f8f4d590fad395ad90285ea9755d1f0bf69108d",
      "date": "2026-06-02T15:13:03+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance `stratum init` with ReAct Explorer for improved context capture"
    },
    {
      "sha": "a0fe252a8d7d8047ce745b20c0ac802fbbc2dec8",
      "date": "2026-05-30T21:53:54+02:00",
      "author": "Javi_1",
      "subject": "feat: mark tasks as completed in Memory Layer 1 milestone"
    },
    {
      "sha": "59e4485bcc0ae095bf4660e797db651c9aeca801",
      "date": "2026-05-30T21:01:41+02:00",
      "author": "Javi_1",
      "subject": "fix: update model version from qwen2.5-coder:32b to qwen3.5:9b in configuration files"
    },
    {
      "sha": "1da42a97a308d9a4364522a965014730b98fa9b7",
      "date": "2026-05-30T20:54:45+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance InitAgent to include provider information and improve error handling"
    },
    {
      "sha": "e4028acd1b00c9c3e899fa711f43b0a99d631b48",
      "date": "2026-05-30T18:04:14+02:00",
      "author": "Javi_1",
      "subject": "refactor: improve documentation prompt and structure in update-docs hook"
    },
    {
      "sha": "dce28300bcb12ee4729630b6671757d23aa259c4",
      "date": "2026-05-30T11:58:11+02:00",
      "author": "Javi_1",
      "subject": "refactor: update documentation hook to improve clarity and functionality"
    },
    {
      "sha": "7a568c6047e65b43824b6478c6f61e034b871f3b",
      "date": "2026-05-30T11:38:09+02:00",
      "author": "Javi_1",
      "subject": "docs: update README with current status, features, and repository structure"
    },
    {
      "sha": "c0035853444c9d147d488146948b935c09bfc944",
      "date": "2026-05-30T11:26:10+02:00",
      "author": "Javi_1",
      "subject": "fix: inyectar gestor de paquetes detectado en el contexto de síntesis (§1.4)"
    },
    {
      "sha": "b53222d608c716740eff2c3ca3092cc4f85d01a5",
      "date": "2026-05-30T11:17:07+02:00",
      "author": "Javi_1",
      "subject": "feat: add initial README for Stratum CLI with installation, usage, and configuration details"
    },
    {
      "sha": "b0b97171bcd83b8a904cbf616a58b2260afb1c63",
      "date": "2026-05-30T11:15:48+02:00",
      "author": "Javi_1",
      "subject": "feat: implementar mejoras completas del comando init (Bloques 0-3)"
    },
    {
      "sha": "a4fc77993e8d7b9822356153ff74212dc3f89e51",
      "date": "2026-05-30T10:48:41+02:00",
      "author": "Javi_1",
      "subject": "feat: implement improvements for the `init` command, including enhanced section handling and project detection"
    },
    {
      "sha": "351de4c5eac76af07fdd913dc40b72e1dfdfd849",
      "date": "2026-05-29T21:43:02+02:00",
      "author": "Javi_1",
      "subject": "docs: add README for stratum-cli"
    },
    {
      "sha": "3278dc6678a35f009390f5996e53cb742a400bf8",
      "date": "2026-05-29T20:40:37+02:00",
      "author": "Javi_1",
      "subject": "feat: add analysis for improving `/init` command and `STRATUM.md` generation"
    },
    {
      "sha": "c48fce7ec9a8c02ef147f80a1f2785c73d644790",
      "date": "2026-05-29T20:24:41+02:00",
      "author": "Javi_1",
      "subject": "fix: increase timeout duration for AbortSignal in InitAgent"
    },
    {
      "sha": "b84300485cb59f80266c3a0e0384e6224c128538",
      "date": "2026-05-29T20:21:57+02:00",
      "author": "Javi_1",
      "subject": "fix: update onSend handler in Banner component to use handleSend function"
    },
    {
      "sha": "efc4d7be4e3dce9136826f9a0eed8af976ee4288",
      "date": "2026-05-29T20:13:21+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance SSH client with connection pooling, command execution options, and security features"
    },
    {
      "sha": "fcbe735aef9468fe8a360e0cc3c3e719a3fcbbf0",
      "date": "2026-05-29T20:07:30+02:00",
      "author": "Javi_1",
      "subject": "feat: add native SSH client support with connection pooling and file transfer tools"
    },
    {
      "sha": "15ebde52f42f3f7d198b610e1832adf4f8d35132",
      "date": "2026-05-29T19:20:54+02:00",
      "author": "Javi_1",
      "subject": "feat: implement tool session disabling and enhance tool schema filtering"
    },
    {
      "sha": "a827ea74bc58919df78c539782e5b2fc58752a6e",
      "date": "2026-05-29T18:33:04+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance .gitignore handling and add lastPrompt tracking in SynthesisProvider"
    },
    {
      "sha": "7b9255c4cb7f918f7d4a7903fc55a65ef8cbbc3d",
      "date": "2026-05-29T18:23:08+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance command input area with real-time autocompletion and add CommandPalette component"
    },
    {
      "sha": "49b482e05bbdcb96efbe385fffba40e3f45dd0f0",
      "date": "2026-05-29T18:16:31+02:00",
      "author": "Javi_1",
      "subject": "Fix , implement Hito 2"
    },
    {
      "sha": "4e668573ae64ce806a7cfd296f8b53bee9e1f1e8",
      "date": "2026-05-29T17:56:13+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance session management and add diagnostic commands"
    },
    {
      "sha": "71a9f7dc33b80be36347d6eb8720159946e8cf52",
      "date": "2026-05-29T17:26:37+02:00",
      "author": "Javi_1",
      "subject": "feat: add packing step to GitHub release workflow"
    },
    {
      "sha": "a6cfb54184e75b546c83c9b285ca4e0ba74aee2d",
      "date": "2026-05-29T14:31:25+02:00",
      "author": "Javi_1",
      "subject": "DOC, implementacion Hito2. Actualiza la documentación de los módulos CLI, config, memory, providers y sessions para reflejar los cambios en la implementación y el estado de los hitos. Se añade el módulo de memoria y se implementan nuevas funcionalidades en el manejo de sesiones. Se corrigen fechas y se amplían descripciones en el roadmap. Se mejora la gestión de comandos y se documentan nuevas características como la compresión de contexto y la persistencia de sesiones."
    },
    {
      "sha": "4d4eb0395f82935ba68575a0c5b8117f51a5342d",
      "date": "2026-05-29T14:07:02+02:00",
      "author": "Javi_1",
      "subject": "feat: implement Hito 2 — Memory Layer 1"
    },
    {
      "sha": "8db12142f469a826ea716c5fe45dc086781a1a07",
      "date": "2026-05-29T08:27:40+02:00",
      "author": "Javi_1",
      "subject": "chore: release v0.1.4"
    },
    {
      "sha": "9525c75fbf07e2269573180673cba22aa547217f",
      "date": "2026-05-29T08:27:19+02:00",
      "author": "Javi_1",
      "subject": "chore: remove npm publish step until NPM_TOKEN is configured"
    },
    {
      "sha": "8d60af60fc06f0685e49011dc3b03eb9a64c249e",
      "date": "2026-05-29T08:14:29+02:00",
      "author": "Javi_1",
      "subject": "chore: release v0.1.3"
    },
    {
      "sha": "9af69a7de4ece31052be9e0a771e19ba687da06e",
      "date": "2026-05-29T08:14:00+02:00",
      "author": "Javi_1",
      "subject": "fix: kill entire process group on timeout to prevent orphan processes blocking streams on Linux"
    },
    {
      "sha": "ac215cb1999747120adc4dd34f6663051f8900ac",
      "date": "2026-05-28T23:28:44+02:00",
      "author": "Javi_1",
      "subject": "fix: release script manages git commit and tag directly to avoid Windows npm-git integration issues"
    },
    {
      "sha": "817f645485bbddc1af563cd48e1fef7094316cdc",
      "date": "2026-05-28T23:27:20+02:00",
      "author": "Javi_1",
      "subject": "chore: release v0.1.2"
    },
    {
      "sha": "aa61391f90af3afb4849d9e59c1c72f26594ed7c",
      "date": "2026-05-28T22:43:34+02:00",
      "author": "Javi_1",
      "subject": "feat: bump version to 0.1.1 in package.json and package-lock.json"
    },
    {
      "sha": "637994d4448377d2976d8922467d287cb6cd83a3",
      "date": "2026-05-28T22:33:52+02:00",
      "author": "Javi_1",
      "subject": "feat: add GitHub Actions workflow for automated release process"
    },
    {
      "sha": "73de0ddd205fe11f65459f014d8a51abf3c23535",
      "date": "2026-05-28T22:33:41+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance ESLint rules and add release script for version management"
    },
    {
      "sha": "6c2319e71fd05c16c8cf3724965d36d7b9e0a61c",
      "date": "2026-05-28T22:02:02+02:00",
      "author": "Javi_1",
      "subject": "feat: add versioning strategy and release pipeline details to project definition"
    },
    {
      "sha": "aa64b6509dfb0e670a4617ce4a611968906a9e7c",
      "date": "2026-05-28T21:53:45+02:00",
      "author": "Javi_1",
      "subject": "feat: add `/init` command to scan project and generate/update `STRATUM.md`"
    },
    {
      "sha": "c1e949957146e92645be5b23c73f38c670c4e55a",
      "date": "2026-05-28T21:29:32+02:00",
      "author": "Javi_1",
      "subject": "feat: extend AgentEvent.done to include 'error' stop reason and update UI specifications for scrolling behavior"
    },
    {
      "sha": "dacf71ddf0cd70d0dde24615214a5153388219b4",
      "date": "2026-05-28T21:14:00+02:00",
      "author": "Javi_1",
      "subject": "feat: update project definition with healthCheck implementation details and decision ID generation process"
    },
    {
      "sha": "b7d025f95be402997f3fdaafbf63b4fdad0ee87a",
      "date": "2026-05-28T20:39:23+02:00",
      "author": "Javi_1",
      "subject": "feat: implement dual-mode markdown rendering for agent responses"
    },
    {
      "sha": "4f5116040e5ac28b50516df0a9eead5a71ab7a33",
      "date": "2026-05-28T16:53:49+02:00",
      "author": "Javi_1",
      "subject": "feat: update milestone 1 tasks to completed in project definition"
    },
    {
      "sha": "e6bc5e3a6057340ff486ae671e4356868d5b7f51",
      "date": "2026-05-28T15:23:35+02:00",
      "author": "Javi_1",
      "subject": "test: add tests for runCommand and useAgentStream functionality"
    },
    {
      "sha": "c89257705e735c02a927d8db6d58e3851a81757f",
      "date": "2026-05-28T15:12:04+02:00",
      "author": "Javi_1",
      "subject": "fix: handle AbortError in streamWithRetry and improve error formatting in run command"
    },
    {
      "sha": "a2ff856e70ea852c936a18ecf5d906a9c55e5fc1",
      "date": "2026-05-28T14:33:42+02:00",
      "author": "Javi_1",
      "subject": "feat: enhance shell command instructions for Windows and update bash tool shell handling"
    },
    {
      "sha": "9695c55033de65fb7c965de804fc3a9db30ffed5",
      "date": "2026-05-28T14:18:57+02:00",
      "author": "Javi_1",
      "subject": "style: aplicar formato Prettier a todo el codebase"
    },
    {
      "sha": "f7f10219bc22de5cfaa0794241adfe71b489ed5b",
      "date": "2026-05-28T14:16:56+02:00",
      "author": "Javi_1",
      "subject": "fix: update hook file paths to absolute paths in settings.json"
    },
    {
      "sha": "736b858140a2b4acad271267301faacde1754bc2",
      "date": "2026-05-28T14:11:42+02:00",
      "author": "Javi_1",
      "subject": "fix: corregir incumplimientos de spec 12.1 y 12.3 en el core agent loop"
    },
    {
      "sha": "8896661cc013127d978cad048147c5077de56d45",
      "date": "2026-05-28T13:41:06+02:00",
      "author": "Javi_1",
      "subject": "feat: implement Hito 1 — Core Agent Loop"
    },
    {
      "sha": "48f75fc4aa23b169dbb8d79a0df23e61f76f3e0a",
      "date": "2026-05-28T09:49:18+02:00",
      "author": "Javi_1",
      "subject": "feat: add hooks for documentation updates, linting, and distribution blocking in settings"
    },
    {
      "sha": "2254bfb91f3077d0c6b6e85022b669f7faebb0a2",
      "date": "2026-05-28T09:41:24+02:00",
      "author": "Javi_1",
      "subject": "feat: add hooks for documentation updates, linting, and validation in Stratum CLI"
    },
    {
      "sha": "91091756ca1a4a733034a75ff777eeca50c9b5a9",
      "date": "2026-05-28T09:40:55+02:00",
      "author": "Javi_1",
      "subject": "feat: add architecture and roadmap documentation for Stratum CLI"
    },
    {
      "sha": "204786912edf5b50798778256a4d7abd1aa592f9",
      "date": "2026-05-27T23:41:18+02:00",
      "author": "Javi_1",
      "subject": "feat: implement Hito 0 — Stratum CLI scaffolding"
    },
    {
      "sha": "3e622b8f46c35abe6065fdc100c4e58fafd62fca",
      "date": "2026-05-27T21:22:48+02:00",
      "author": "Javi_1",
      "subject": "Update UI specifications and implementation details for Stratum CLI, including enhancements to the ASCII art display and color handling in terminal interactions."
    },
    {
      "sha": "27f79c8b93859c844db3a021101cbba4754e43a3",
      "date": "2026-05-27T21:07:48+02:00",
      "author": "Javi_1",
      "subject": "Add UI specifications for various components and functionalities in Stratum CLI"
    },
    {
      "sha": "ea5068f6991da48334c5950465a4c225231d7402",
      "date": "2026-05-27T20:57:52+02:00",
      "author": "Javi_1",
      "subject": "Add related documents section to project definition and create UI specification document"
    },
    {
      "sha": "aad9f3ba90c12b07f06c351a7774875c1f70356a",
      "date": "2026-05-27T20:38:57+02:00",
      "author": "Javi_1",
      "subject": "Add detailed technical specifications and event schema for Stratum CLI"
    },
    {
      "sha": "2ce1ac8aab4f49e9d7bfe4301299f7fd8b21ec2c",
      "date": "2026-05-27T19:49:09+02:00",
      "author": "Javi_1",
      "subject": "first commit"
    }
  ]
};
